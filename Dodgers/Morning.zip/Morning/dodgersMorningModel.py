class DodgersMorningModel:
    def __init__(self, awayTeam, homeTeam, win, dodgersScore, opponentScore, boxScoreLink, place, record):
        self.awayTeam = awayTeam
        self.homeTeam = homeTeam
        self.win = win
        self.dodgersScore = dodgersScore
        self.opponentScore = opponentScore
        self.boxScoreLink = boxScoreLink
        self.place = place
        self.record = record